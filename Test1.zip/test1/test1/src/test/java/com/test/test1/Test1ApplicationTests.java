package com.test.test1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootTest
@RestController
@RequestMapping("/api")
class Test1ApplicationTests {

	@Test
	void contextLoads() {
	}
	@GetMapping("/")
	public String home() {
		return ("<h1>Hello!</h1>");
	}
	@GetMapping("/user")
	public String user() {
		return ("<h1>Hello, User!</h1>");
	}
	@GetMapping("/admin")
	public String admin() {
		return ("<h1>Hello, Admin!</h1>");
	}
}
