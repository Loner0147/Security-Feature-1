package com.test.test1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping ("/api")
public class TestController {

    //http://localhost:8080/api/norm
    @GetMapping("/norm")
	public String home() {
		return ("<h1>Hello!</h1>");
	}

    // http://localhost:8080/api/user
	@GetMapping("/user")
	public String user() {
		return ("<h1>Hello, User!</h1>");
	}

    // http://localhost:8080/api/admin
	@GetMapping("/admin")
	public String admin() {
		return ("<h1>Hello, Admin!</h1>");
	}

}
